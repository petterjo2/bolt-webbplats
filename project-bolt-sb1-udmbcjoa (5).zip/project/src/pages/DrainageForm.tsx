import React, { useState } from 'react';
import FormLayout from '../components/FormLayout';
import { Droplets, Send } from 'lucide-react';

const DrainageForm = () => {
  const [formData, setFormData] = useState({
    // Qualifying questions
    hasBasement: '',
    moistureProblems: '',
    lastDrainage: '',
    wantQuote: '',
    // Contact fields
    name: '',
    email: '',
    phone: '',
    address: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const form = e.target as HTMLFormElement;
      const formData = new FormData(form);
      
      const response = await fetch('/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(formData as any).toString()
      });

      if (response.ok) {
        setIsSubmitted(true);
      } else {
        throw new Error('Form submission failed');
      }
    } catch (error) {
      console.error('Error submitting form:', error);
      alert('Ett fel uppstod. Försök igen eller kontakta oss direkt.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const updateField = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  if (isSubmitted) {
    return (
      <FormLayout
        title="Tack för din förfrågan!"
        description="Vi har mottagit din förfrågan om dränering och kommer att kontakta dig inom kort."
        icon={Droplets}
        iconColor="bg-green-500"
      >
        <div className="text-center space-y-6">
          <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto">
            <Send className="w-10 h-10 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Din förfrågan är skickad!
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              Vi kommer att kontakta dig inom 24 timmar med kostnadsfria offerter från verifierade dräneringsföretag.
            </p>
            <div className="bg-blue-50 p-6 rounded-lg">
              <h3 className="font-semibold text-blue-900 mb-2">Vad händer nu?</h3>
              <ul className="text-blue-800 text-sm space-y-1 text-left">
                <li>✓ Vi matchar dig med lämpliga dräneringsföretag</li>
                <li>✓ Du får upp till 3 kostnadsfria offerter</li>
                <li>✓ Alla företag är verifierade och försäkrade</li>
                <li>✓ Du väljer själv vilket företag du vill använda</li>
              </ul>
            </div>
          </div>
        </div>
      </FormLayout>
    );
  }

  return (
    <FormLayout
      title="Dränering"
      description="Få kostnadsfria offerter för dränering av husgrund. Skydda ditt hem mot fukt och vattenskador."
      icon={Droplets}
      iconColor="bg-blue-500"
    >
      <form 
        name="drainage"
        method="POST"
        data-netlify="true"
        netlify-honeypot="bot-field"
        onSubmit={handleSubmit} 
        className="space-y-8"
      >
        <input type="hidden" name="form-name" value="drainage" />
        <input type="hidden" name="bot-field" />
        
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Berätta om ditt projekt</h2>
          
          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              Har huset en källare?
              <span className="text-red-500 ml-1">*</span>
            </label>
            <div className="space-y-3">
              {[
                { value: 'yes', label: 'Ja' },
                { value: 'no', label: 'Nej' },
                { value: 'partial', label: 'Delvis/krypgrund' }
              ].map((option) => (
                <label key={option.value} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="radio"
                    name="hasBasement"
                    value={option.value}
                    checked={formData.hasBasement === option.value}
                    onChange={(e) => updateField('hasBasement', e.target.value)}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                    required
                  />
                  <span className="text-gray-700">{option.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              Har du märkt fukt eller lukt i källaren?
              <span className="text-red-500 ml-1">*</span>
            </label>
            <div className="space-y-3">
              {[
                { value: 'yes-both', label: 'Ja, både fukt och lukt' },
                { value: 'yes-moisture', label: 'Ja, fuktproblem' },
                { value: 'yes-smell', label: 'Ja, mögel/fuktlukt' },
                { value: 'no', label: 'Nej, inga problem' },
                { value: 'unsure', label: 'Osäker' }
              ].map((option) => (
                <label key={option.value} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="radio"
                    name="moistureProblems"
                    value={option.value}
                    checked={formData.moistureProblems === option.value}
                    onChange={(e) => updateField('moistureProblems', e.target.value)}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                    required
                  />
                  <span className="text-gray-700">{option.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              Vet du när dränering senast gjordes?
              <span className="text-red-500 ml-1">*</span>
            </label>
            <div className="space-y-3">
              {[
                { value: 'never', label: 'Aldrig/vet ej' },
                { value: 'over-20-years', label: 'Över 20 år sedan' },
                { value: '10-20-years', label: '10-20 år sedan' },
                { value: 'under-10-years', label: 'Under 10 år sedan' }
              ].map((option) => (
                <label key={option.value} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="radio"
                    name="lastDrainage"
                    value={option.value}
                    checked={formData.lastDrainage === option.value}
                    onChange={(e) => updateField('lastDrainage', e.target.value)}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                    required
                  />
                  <span className="text-gray-700">{option.label}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="mb-6">
            <label className="block text-sm font-semibold text-gray-700 mb-3">
              Vill du få en kostnadsfri offert på ny dränering?
              <span className="text-red-500 ml-1">*</span>
            </label>
            <div className="space-y-3">
              {[
                { value: 'yes-urgent', label: 'Ja, det är akut' },
                { value: 'yes-planning', label: 'Ja, jag planerar' },
                { value: 'yes-information', label: 'Ja, vill bara ha information' },
                { value: 'unsure', label: 'Osäker, vill veta mer' }
              ].map((option) => (
                <label key={option.value} className="flex items-center space-x-3 cursor-pointer">
                  <input
                    type="radio"
                    name="wantQuote"
                    value={option.value}
                    checked={formData.wantQuote === option.value}
                    onChange={(e) => updateField('wantQuote', e.target.value)}
                    className="w-4 h-4 text-blue-600 focus:ring-blue-500 border-gray-300"
                    required
                  />
                  <span className="text-gray-700">{option.label}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        <hr className="border-gray-200" />

        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Dina kontaktuppgifter</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                Namn
                <span className="text-red-500 ml-1">*</span>
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={(e) => updateField('name', e.target.value)}
                placeholder="Ditt för- och efternamn"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                E-post
                <span className="text-red-500 ml-1">*</span>
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={(e) => updateField('email', e.target.value)}
                placeholder="din@email.se"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                Telefonnummer
                <span className="text-red-500 ml-1">*</span>
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={(e) => updateField('phone', e.target.value)}
                placeholder="070-123 45 67"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-3">
                Adress
                <span className="text-red-500 ml-1">*</span>
              </label>
              <input
                type="text"
                name="address"
                value={formData.address}
                onChange={(e) => updateField('address', e.target.value)}
                placeholder="Gata, Postnummer, Ort"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                required
              />
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isSubmitting ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              <span>Skickar...</span>
            </>
          ) : (
            <>
              <Send className="w-5 h-5" />
              <span>Skicka förfrågan</span>
            </>
          )}
        </button>

        <p className="text-sm text-gray-500 text-center">
          Genom att skicka förfrågan godkänner du att vi kontaktar dig med offerter. 
          Kostnadsfritt och utan förpliktelser.
        </p>
      </form>
    </FormLayout>
  );
};

export default DrainageForm;