import React from 'react';
import { Users, Award, Target, Heart, Shield, TrendingUp, CheckCircle } from 'lucide-react';

const FixviaLogo = ({ size = 'large' }) => (
  <div className="flex items-center justify-center">
    <div className="relative">
      {/* Main circle with gradient */}
      <div className={`${size === 'large' ? 'w-10 h-10' : 'w-8 h-8'} bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center shadow-lg`}>
        <div className={`${size === 'large' ? 'w-4 h-4' : 'w-3 h-3'} bg-white rounded-full`}></div>
      </div>
      {/* Accent dot */}
      <div className={`absolute -top-1 -right-1 ${size === 'large' ? 'w-4 h-4' : 'w-3 h-3'} bg-blue-400 rounded-full opacity-80`}></div>
    </div>
  </div>
);

const AboutUs = () => {
  const values = [
    {
      icon: Heart,
      title: 'Kundnöjdhet först',
      description: 'Vi sätter alltid våra kunders behov och tillfredsställelse i centrum av allt vi gör.'
    },
    {
      icon: Shield,
      title: 'Trygghet och kvalitet',
      description: 'Alla våra partners är noggrant verifierade för att garantera högsta kvalitet och trygghet.'
    },
    {
      icon: TrendingUp,
      title: 'Innovation och utveckling',
      description: 'Vi utvecklar ständigt vår plattform för att erbjuda den bästa upplevelsen för alla parter.'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-white bg-opacity-20 rounded-full mb-6">
              <FixviaLogo />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold mb-6">
              Om Fixvia
            </h1>
            <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto">
              Vi gör hemförbättring enkelt, tryggt och prisvärt för alla svenska villaägare.
            </p>
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Vår mission
              </h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                Fixvia grundades 2020 med en enkel vision: att göra hemförbättring tillgängligt, 
                transparent och stressfritt för alla svenska villaägare. Vi såg hur komplicerat och 
                tidskrävande det var att hitta pålitliga företag och jämföra offerter.
              </p>
              <p className="text-lg text-gray-600 mb-8 leading-relaxed">
                Idag hjälper vi tusentals familjer varje månad att förverkliga sina hemförbättringsdrömmar 
                genom att koppla ihop dem med Sveriges bästa och mest pålitliga företag.
              </p>
              <div className="flex items-center space-x-2">
                <Target className="w-6 h-6 text-blue-600" />
                <span className="text-lg font-semibold text-gray-900">
                  Att göra hemförbättring enkelt för alla
                </span>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop" 
                alt="Hemförbättring" 
                className="rounded-xl shadow-lg"
              />
              <div className="absolute -bottom-6 -left-6 bg-blue-600 text-white p-6 rounded-lg shadow-lg">
                <div className="text-2xl font-bold">4+ år</div>
                <div className="text-sm">av förtroende</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Våra värderingar
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Dessa värderingar styr allt vi gör och hjälper oss att leverera den bästa servicen till våra kunder.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, index) => {
              const IconComponent = value.icon;
              return (
                <div key={index} className="bg-white rounded-xl shadow-lg p-8 text-center">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-blue-100 rounded-full mb-6">
                    <IconComponent className="w-8 h-8 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">{value.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Varför välja Fixvia?
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Vi gör skillnaden genom att erbjuda en komplett lösning för alla dina hemförbättringsbehov.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {[
              'Kostnadsfritt för kunder - inga dolda avgifter',
              'Endast verifierade och kvalitetssäkrade företag',
              'Personlig rådgivning från våra experter',
              'Snabb och enkel process - få offerter inom 24 timmar',
              'Omfattande kunskapsbank med tips och guider',
              'Kundservice som alltid finns tillgänglig',
              'Transparenta priser och tydliga offerter',
              'Miljömedvetna och hållbara lösningar'
            ].map((benefit, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0 mt-1" />
                <span className="text-gray-700 text-lg">{benefit}</span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutUs;