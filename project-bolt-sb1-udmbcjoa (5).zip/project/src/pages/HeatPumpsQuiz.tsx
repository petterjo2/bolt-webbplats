import React, { useState } from 'react';
import { ArrowRight, ArrowLeft, Upload, CheckCircle, Home, Building, TreePine, Warehouse, Calendar, Palette, Columns, TreeDeciduous, HelpCircle, Eye, Zap, VolumeX, Shield, Camera, ImageIcon, Sparkles, Thermometer, DollarSign, Leaf, Battery, TrendingUp } from 'lucide-react';

interface QuizData {
  houseType: string;
  currentHeating: string;
  pumpType: string;
  priority: string;
  name: string;
  email: string;
  phone: string;
  address: string;
  image?: File;
  imageUrl?: string;
}

const HeatPumpsQuiz = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [quizData, setQuizData] = useState<QuizData>({
    houseType: '',
    currentHeating: '',
    pumpType: '',
    priority: '',
    name: '',
    email: '',
    phone: '',
    address: '',
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);
  const [imageUploadStatus, setImageUploadStatus] = useState<'idle' | 'uploading' | 'success' | 'error'>('idle');
  const [uploadError, setUploadError] = useState<string>('');

  const updateQuizData = (field: keyof QuizData, value: string | File) => {
    setQuizData(prev => ({ ...prev, [field]: value }));
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageUploadStatus('uploading');
      setUploadError('');
      
      try {
        // Validate file size (max 10MB)
        if (file.size > 10 * 1024 * 1024) {
          throw new Error('Filen är för stor. Max 10MB tillåtet.');
        }
        
        // Validate file type
        if (!file.type.match(/^image\/(jpeg|jpg|png)$/)) {
          throw new Error('Endast JPG och PNG-filer är tillåtna.');
        }
        
        // Simulate upload delay for better UX
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Store file locally and create object URL for preview
        const imageUrl = URL.createObjectURL(file);
        updateQuizData('image', file);
        updateQuizData('imageUrl', imageUrl);
        setImageUploadStatus('success');
        
      } catch (error) {
        console.error('Image upload error:', error);
        setUploadError(error instanceof Error ? error.message : 'Ett oväntat fel uppstod');
        setImageUploadStatus('error');
      }
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    try {
      // Facebook Pixel tracking för konvertering
      if (typeof window !== 'undefined' && (window as any).fbq) {
        (window as any).fbq('track', 'Lead', {
          content_name: 'Värmepumpar Quiz',
          content_category: 'Heat Pumps',
          value: 1,
          currency: 'SEK'
        });
      }

      // Skicka data till Make webhook
      const webhookData = {
        timestamp: new Date().toISOString(),
        source: 'fixvia.se/varmepumpar',
        houseType: quizData.houseType,
        currentHeating: quizData.currentHeating,
        pumpType: quizData.pumpType,
        priority: quizData.priority,
        name: quizData.name,
        email: quizData.email,
        phone: quizData.phone,
        address: quizData.address,
        hasImage: !!quizData.image,
        imageUrl: quizData.imageUrl || null,
        imageName: quizData.image?.name || null,
        imageSize: quizData.image?.size || null
      };

      // Ersätt med din faktiska webhook URL
      const webhookUrl = 'https://hook.eu2.make.com/YOUR_WEBHOOK_ID';
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(webhookData)
      });

      if (response.ok) {
        setIsCompleted(true);
      } else {
        throw new Error('Webhook submission failed');
      }
    } catch (error) {
      console.error('Error submitting quiz:', error);
      // Visa success även om webhook misslyckas
      setIsCompleted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1: return quizData.houseType !== '';
      case 2: return quizData.currentHeating !== '';
      case 3: return quizData.pumpType !== '';
      case 4: return quizData.priority !== '';
      case 5: return quizData.name && quizData.email && quizData.phone && quizData.address;
      case 6: return true; // Image upload is optional
      default: return true;
    }
  };

  const steps = [
    // Step 0: Introduction
    {
      title: "Se hur ditt hus kan se ut med värmepump",
      subtitle: "Svara på några snabba frågor och ladda upp en bild – så visar vi hur ditt hem kan få en energieffektiv värmepump och hur mycket du kan spara.",
      content: (
        <div className="text-center space-y-12">
          {/* Three feature cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="w-20 h-20 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <HelpCircle className="w-8 h-8 text-red-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Svara på frågor</h3>
              <p className="text-gray-600">Berätta om ditt hus och dina uppvärmningsbehov</p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Camera className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Ladda upp foto</h3>
              <p className="text-gray-600">Visa oss ditt hus och nuvarande uppvärmning</p>
            </div>
            
            <div className="text-center">
              <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Sparkles className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Få visualisering</h3>
              <p className="text-gray-600">Se hur värmepump kan se ut på ditt hus</p>
            </div>
          </div>

          <button
            onClick={nextStep}
            className="bg-red-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-red-700 transition-colors flex items-center justify-center space-x-2 text-lg mx-auto"
          >
            <span>Starta guiden</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      )
    },

    // Step 1: House Type
    {
      title: "Vilken typ av hus bor du i?",
      subtitle: "Detta hjälper oss att beräkna rätt storlek på värmepumpen",
      content: (
        <div className="space-y-4 max-w-2xl mx-auto">
          {[
            { value: 'villa', label: 'Villa', icon: Home, bgColor: 'bg-orange-50', iconColor: 'text-orange-500' },
            { value: 'radhus', label: 'Radhus', icon: Building, bgColor: 'bg-green-50', iconColor: 'text-green-500' },
            { value: 'fritidshus', label: 'Fritidshus', icon: TreePine, bgColor: 'bg-purple-50', iconColor: 'text-purple-500' },
            { value: 'annat', label: 'Annat', icon: Warehouse, bgColor: 'bg-gray-50', iconColor: 'text-gray-500' }
          ].map((option) => {
            const IconComponent = option.icon;
            return (
              <button
                key={option.value}
                onClick={() => updateQuizData('houseType', option.value)}
                className={`w-full p-6 rounded-xl border-2 transition-all flex items-center space-x-4 ${
                  quizData.houseType === option.value
                    ? 'border-red-500 bg-red-50'
                    : 'border-gray-200 hover:border-gray-300 bg-white'
                }`}
              >
                <div className={`w-12 h-12 ${option.bgColor} rounded-full flex items-center justify-center`}>
                  <IconComponent className={`w-6 h-6 ${option.iconColor}`} />
                </div>
                <span className="text-lg font-medium text-gray-900">{option.label}</span>
              </button>
            );
          })}
        </div>
      )
    },

    // Step 2: Current Heating
    {
      title: "Vad har du för uppvärmning idag?",
      subtitle: "Detta hjälper oss att beräkna din potentiella besparing",
      content: (
        <div className="space-y-4 max-w-2xl mx-auto">
          {[
            { value: 'direktel', label: 'Direktverkande el', icon: Zap, bgColor: 'bg-yellow-50', iconColor: 'text-yellow-500' },
            { value: 'olja', label: 'Olja', icon: Thermometer, bgColor: 'bg-orange-50', iconColor: 'text-orange-500' },
            { value: 'pellets', label: 'Pellets', icon: TreeDeciduous, bgColor: 'bg-green-50', iconColor: 'text-green-500' },
            { value: 'ved', label: 'Ved', icon: TreePine, bgColor: 'bg-brown-50', iconColor: 'text-brown-500' },
            { value: 'fjarrvarme', label: 'Fjärrvärme', icon: Building, bgColor: 'bg-blue-50', iconColor: 'text-blue-500' },
            { value: 'annat', label: 'Annat', icon: HelpCircle, bgColor: 'bg-gray-50', iconColor: 'text-gray-500' }
          ].map((option) => {
            const IconComponent = option.icon;
            return (
              <button
                key={option.value}
                onClick={() => updateQuizData('currentHeating', option.value)}
                className={`w-full p-6 rounded-xl border-2 transition-all flex items-center space-x-4 ${
                  quizData.currentHeating === option.value
                    ? 'border-red-500 bg-red-50'
                    : 'border-gray-200 hover:border-gray-300 bg-white'
                }`}
              >
                <div className={`w-12 h-12 ${option.bgColor} rounded-full flex items-center justify-center`}>
                  <IconComponent className={`w-6 h-6 ${option.iconColor}`} />
                </div>
                <span className="text-lg font-medium text-gray-900">{option.label}</span>
              </button>
            );
          })}
        </div>
      )
    },

    // Step 3: Pump Type
    {
      title: "Vilken typ av värmepump är du intresserad av?",
      subtitle: "Olika värmepumpar passar olika hus och behov",
      content: (
        <div className="space-y-4 max-w-2xl mx-auto">
          {[
            { 
              value: 'luft-luft', 
              label: 'Luft-till-luft värmepump', 
              description: 'Enklast att installera, värmer luften direkt',
              icon: Zap, 
              bgColor: 'bg-blue-50', 
              iconColor: 'text-blue-500' 
            },
            { 
              value: 'luft-vatten', 
              label: 'Luft-till-vatten värmepump', 
              description: 'Kopplas till befintligt värmesystem',
              icon: Thermometer, 
              bgColor: 'bg-green-50', 
              iconColor: 'text-green-500' 
            },
            { 
              value: 'bergvarme', 
              label: 'Bergvärmepump', 
              description: 'Högst verkningsgrad, kräver borrning',
              icon: TrendingUp, 
              bgColor: 'bg-purple-50', 
              iconColor: 'text-purple-500' 
            },
            { 
              value: 'vet-ej', 
              label: 'Vet ej', 
              description: 'Osäker, vill ha rådgivning',
              icon: HelpCircle, 
              bgColor: 'bg-orange-50', 
              iconColor: 'text-orange-500' 
            }
          ].map((option) => {
            const IconComponent = option.icon;
            return (
              <button
                key={option.value}
                onClick={() => updateQuizData('pumpType', option.value)}
                className={`w-full p-6 rounded-xl border-2 transition-all text-left ${
                  quizData.pumpType === option.value
                    ? 'border-red-500 bg-red-50'
                    : 'border-gray-200 hover:border-gray-300 bg-white'
                }`}
              >
                <div className="flex items-start space-x-4">
                  <div className={`w-12 h-12 ${option.bgColor} rounded-full flex items-center justify-center flex-shrink-0`}>
                    <IconComponent className={`w-6 h-6 ${option.iconColor}`} />
                  </div>
                  <div>
                    <h3 className="text-lg font-medium text-gray-900 mb-1">{option.label}</h3>
                    <p className="text-gray-600">{option.description}</p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      )
    },

    // Step 4: Priority
    {
      title: "Vad är viktigast för dig?",
      subtitle: "Välj det som känns mest relevant för din värmepump",
      content: (
        <div className="space-y-4 max-w-2xl mx-auto">
          {[
            { value: 'spara-pengar', label: 'Spara pengar på uppvärmning', icon: DollarSign, bgColor: 'bg-green-50', iconColor: 'text-green-500' },
            { value: 'miljo', label: 'Miljötänk och hållbarhet', icon: Leaf, bgColor: 'bg-green-50', iconColor: 'text-green-600' },
            { value: 'komfort', label: 'Bättre komfort och värme', icon: Thermometer, bgColor: 'bg-red-50', iconColor: 'text-red-500' },
            { value: 'framtidssaker', label: 'Framtidssäkra hemmet', icon: Shield, bgColor: 'bg-purple-50', iconColor: 'text-purple-500' }
          ].map((option) => {
            const IconComponent = option.icon;
            return (
              <button
                key={option.value}
                onClick={() => updateQuizData('priority', option.value)}
                className={`w-full p-6 rounded-xl border-2 transition-all flex items-center space-x-4 ${
                  quizData.priority === option.value
                    ? 'border-red-500 bg-red-50'
                    : 'border-gray-200 hover:border-gray-300 bg-white'
                }`}
              >
                <div className={`w-12 h-12 ${option.bgColor} rounded-full flex items-center justify-center`}>
                  <IconComponent className={`w-6 h-6 ${option.iconColor}`} />
                </div>
                <span className="text-lg font-medium text-gray-900">{option.label}</span>
              </button>
            );
          })}
        </div>
      )
    },

    // Step 5: Contact Information
    {
      title: "Berätta vem du är",
      subtitle: "Vi skickar ditt resultat direkt till dig",
      content: (
        <div className="space-y-6 max-w-2xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Namn *
              </label>
              <input
                type="text"
                value={quizData.name}
                onChange={(e) => updateQuizData('name', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                placeholder="Ditt för- och efternamn"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                E-postadress *
              </label>
              <input
                type="email"
                value={quizData.email}
                onChange={(e) => updateQuizData('email', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                placeholder="din@email.se"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Telefonnummer *
              </label>
              <input
                type="tel"
                value={quizData.phone}
                onChange={(e) => updateQuizData('phone', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                placeholder="070-123 45 67"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Adress *
              </label>
              <input
                type="text"
                value={quizData.address}
                onChange={(e) => updateQuizData('address', e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500"
                placeholder="Gata, Postnummer, Ort"
                required
              />
            </div>
          </div>
        </div>
      )
    },

    // Step 6: Image Upload
    {
      title: "Ladda upp en bild på ditt hus",
      subtitle: "Vi visar hur värmepump kan se ut direkt på ditt hus!",
      content: (
        <div className="space-y-6 max-w-2xl mx-auto">
          <div className={`border-2 border-dashed rounded-xl p-12 text-center transition-colors ${
            imageUploadStatus === 'success' 
              ? 'border-green-400 bg-green-50' 
              : imageUploadStatus === 'error'
              ? 'border-red-400 bg-red-50'
              : imageUploadStatus === 'uploading'
              ? 'border-red-400 bg-red-50'
              : 'border-gray-300 bg-gray-50 hover:border-red-400'
          }`}>
            <input
              type="file"
              accept="image/jpeg,image/png"
              onChange={handleImageUpload}
              className="hidden"
              id="image-upload"
              disabled={imageUploadStatus === 'uploading'}
            />
            <label htmlFor="image-upload" className="cursor-pointer">
              <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                imageUploadStatus === 'success' 
                  ? 'bg-green-100' 
                  : imageUploadStatus === 'error'
                  ? 'bg-red-100'
                  : imageUploadStatus === 'uploading'
                  ? 'bg-red-100'
                  : 'bg-red-100'
              }`}>
                {imageUploadStatus === 'uploading' ? (
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-red-600"></div>
                ) : imageUploadStatus === 'success' ? (
                  <CheckCircle className="w-8 h-8 text-green-600" />
                ) : imageUploadStatus === 'error' ? (
                  <Upload className="w-8 h-8 text-red-600" />
                ) : (
                  <Upload className="w-8 h-8 text-red-600" />
                )}
              </div>
              <p className="text-lg font-medium text-gray-700 mb-2">
                {imageUploadStatus === 'uploading' 
                  ? 'Laddar upp bild...'
                  : imageUploadStatus === 'success' && quizData.image
                  ? `✓ ${quizData.image.name}`
                  : imageUploadStatus === 'error'
                  ? 'Klicka för att försöka igen'
                  : 'Klicka för att ladda upp bild'
                }
              </p>
              <p className="text-sm text-gray-500">
                JPG eller PNG, max 10MB
              </p>
            </label>
          </div>

          {/* Upload Status Messages */}
          {imageUploadStatus === 'success' && (
            <div className="bg-green-50 p-4 rounded-lg border border-green-200">
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div>
                  <p className="text-green-800 font-medium">Bild uppladdad!</p>
                  <p className="text-green-600 text-sm">
                    Din bild är vald och redo för visualisering.
                  </p>
                </div>
              </div>
            </div>
          )}

          {imageUploadStatus === 'error' && (
            <div className="bg-red-50 p-4 rounded-lg border border-red-200">
              <div className="flex items-center space-x-3">
                <div className="w-5 h-5 bg-red-600 rounded-full flex items-center justify-center">
                  <span className="text-white text-xs font-bold">!</span>
                </div>
                <div>
                  <p className="text-red-800 font-medium">Uppladdning misslyckades</p>
                  <p className="text-red-600 text-sm">{uploadError}</p>
                </div>
              </div>
            </div>
          )}

          <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
            <p className="text-yellow-800 text-sm">
              <strong>Tips:</strong> Välj en bild tagen framifrån huset för bästa resultat. 
              Bilden hjälper oss att skapa en mer exakt visualisering av värmepump på ditt hus.
            </p>
          </div>

          {/* Show preview if image is uploaded */}
          {imageUploadStatus === 'success' && quizData.image && (
            <div className="bg-white p-4 rounded-lg border border-gray-200">
              <h4 className="font-medium text-gray-900 mb-3">Förhandsvisning:</h4>
              <div className="flex justify-center">
                <img 
                  src={quizData.imageUrl} 
                  alt="Uppladdad bild" 
                  className="max-w-sm max-h-64 rounded-lg shadow-sm object-cover"
                />
              </div>
              <div className="mt-3 text-center">
                <p className="text-sm text-gray-600">
                  {quizData.image.name} • {(quizData.image.size / 1024 / 1024).toFixed(2)} MB
                </p>
              </div>
            </div>
          )}

          <button
            onClick={handleSubmit}
            disabled={isSubmitting || imageUploadStatus === 'uploading'}
            className="w-full bg-red-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-red-700 transition-colors flex items-center justify-center space-x-2 text-lg disabled:opacity-50"
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                <span>Genererar ditt resultat...</span>
              </>
            ) : imageUploadStatus === 'uploading' ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                <span>Väntar på bilduppladdning...</span>
              </>
            ) : (
              <>
                <span>Visa mitt resultat</span>
              </>
            )}
          </button>

          <p className="text-sm text-gray-500 text-center">
            Du kan fortsätta utan bild, men en bild ger bättre visualisering.
          </p>
        </div>
      )
    }
  ];

  if (isCompleted) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-white" />
            </div>
            
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              🎉 Tack {quizData.name}!
            </h1>
            
            <p className="text-lg text-gray-600 mb-6">
              Vi jobbar på din värmepumpsvisualisering. Du får resultatet via mejl inom kort.
            </p>
            
            <div className="bg-red-50 p-6 rounded-lg mb-8">
              <h3 className="font-semibold text-red-900 mb-2">Vad händer nu?</h3>
              <ul className="text-red-800 text-sm space-y-1 text-left">
                <li>✓ Vi skapar din personliga värmepumpsvisualisering</li>
                <li>✓ Du får resultatet på {quizData.email}</li>
                <li>✓ Vi beräknar din potentiella besparing</li>
                <li>✓ Vi skickar kostnadsfria offerter från verifierade värmepumpsföretag</li>
                <li>✓ En expert kontaktar dig inom 24 timmar</li>
              </ul>
            </div>

            <div className="space-y-4">
              <p className="text-gray-600">
                Under tiden kan du läsa mer om värmepumpar:
              </p>
              
              <a
                href="/kunskapsbank"
                className="inline-flex items-center space-x-2 bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors"
              >
                <span>Läs mer i vår kunskapsbank</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const currentStepData = steps[currentStep];
  const totalSteps = steps.length - 1; // Exclude intro step from count

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header with logo and progress */}
        <div className="flex items-center justify-end mb-8">
          {currentStep > 0 && (
            <div className="text-right">
              <div className="text-sm text-gray-600 mb-1">
                Steg {currentStep} av {totalSteps}
              </div>
              <div className="text-sm text-gray-600">
                {Math.round((currentStep / totalSteps) * 100)}%
              </div>
            </div>
          )}
        </div>

        {/* Progress Bar */}
        {currentStep > 0 && (
          <div className="mb-8">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className="bg-red-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${(currentStep / totalSteps) * 100}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Main Content */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Icon */}
          {currentStep > 0 && (
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Thermometer className="w-8 h-8 text-red-600" />
              </div>
            </div>
          )}

          <div className="text-center mb-8">
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              {currentStepData.title}
            </h1>
            {currentStepData.subtitle && (
              <p className="text-lg text-gray-600 max-w-3xl mx-auto">
                {currentStepData.subtitle}
              </p>
            )}
          </div>

          <div className="mb-8">
            {currentStepData.content}
          </div>

          {/* Navigation */}
          {currentStep > 0 && currentStep < steps.length - 1 && (
            <div className="flex justify-between space-x-4">
              <button
                onClick={prevStep}
                className="flex items-center space-x-2 px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Tillbaka</span>
              </button>

              <button
                onClick={nextStep}
                disabled={!isStepValid()}
                className="flex items-center space-x-2 px-6 py-3 bg-red-600 text-white rounded-lg font-semibold hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <span>Nästa</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default HeatPumpsQuiz;