import React from 'react';
import { Link } from 'react-router-dom';
import { AppWindow as Window, Sun, Droplets, Thermometer, Home, Bath, ArrowRight, CheckCircle, Star, Bell } from 'lucide-react';
import AnimatedCounter from '../components/AnimatedCounter';

const HomePage = () => {
  // Visual services with images
  const visualServices = [
    {
      title: 'Takbyte',
      link: '/takbyte',
      image: '/tak-hemsida-ai.webp'
    },
    {
      title: 'Värmepumpar',
      link: '/varmepumpar',
      image: '/varmepump1-website.webp'
    },
    {
      title: 'Badrumsrenovering',
      link: '/badrumsrenovering',
      image: '/badrum-hemsida-ai.jpg'
    },
    {
      title: 'Fönster & Dörrar',
      link: '/fonster',
      image: 'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
    },
    {
      title: 'Solceller',
      link: '/solceller',
      image: '/solceller-hemsida.jpg'
    },
    {
      title: 'Dränering',
      link: '/dranering',
      image: 'https://images.pexels.com/photos/1108572/pexels-photo-1108572.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop'
    }
  ];

  const benefits = [
    'Kostnadsfritt och utan förpliktelser',
    'Upp till 3 offerter från verifierade företag',
    'Spara tid och pengar på jämförelser'
  ];

  const testimonials = [
    {
      name: 'Sofia Bergström',
      location: 'Stockholm',
      text: 'Fantastisk service! Fick 3 offerter för nya fönster och sparade över 20 000 kr jämfört med första offerten.',
      rating: 5
    },
    {
      name: 'Magnus Olsson',
      location: 'Göteborg',
      text: 'Snabbt och enkelt att få offerter för solceller. Installationen blev perfekt och vi sparar massor på elräkningen.',
      rating: 5
    },
    {
      name: 'Camilla Holm',
      location: 'Malmö',
      text: 'Trevlig app och lösning! Fick hjälp med värmepump och är supernöjd med både pris och kvalitet.',
      rating: 5
    },
    {
      name: 'Johan Lindberg',
      location: 'Uppsala',
      text: 'Professionell hantering från start till mål. Dräneringen löste våra fuktproblem helt och hållet.',
      rating: 5
    },
    {
      name: 'Emma Sandberg',
      location: 'Västerås',
      text: 'Bästa beslutet vi gjort! Nytt tak och badrummet blev fantastiskt - huset känns som nytt.',
      rating: 5
    },
    {
      name: 'Robert Hedström',
      location: 'Örebro',
      text: 'Imponerad av servicen. Alla företag var seriösa och professionella. Rekommenderar varmt!',
      rating: 5
    },
    {
      name: 'Lina Forsberg',
      location: 'Linköping',
      text: 'Supersmart med husdokumentation! Sparade både tid och pengar på vårt takbyte.',
      rating: 5
    },
    {
      name: 'Daniel Åberg',
      location: 'Helsingborg',
      text: 'Jättebra historik över alla våra hemförbättringar. Enkelt att hålla koll på garantier och service.',
      rating: 5
    }
  ];

  const stats = [
    { number: 4, label: 'År i branschen', suffix: '' },
    { number: 250, label: 'Verifierade företag', suffix: '+' },
    { number: 478000, label: 'Förmedlade offerter', suffix: '' }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section with buttons */}
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-3xl md:text-5xl font-bold mb-4 leading-tight">
              Din genväg till<br />
              <span className="text-blue-200">trygga val för hemmet</span>
            </h1>
            <p className="text-lg md:text-xl mb-6 text-blue-100 max-w-3xl mx-auto">
              Jämför priser och tjänster för hemförbättring. Vi kopplar ihop dig med Sveriges bästa leverantörer.
            </p>
            <div className="flex flex-wrap justify-center gap-3 mb-8">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-center space-x-2 bg-blue-700 bg-opacity-50 px-3 py-1 rounded-full">
                  <CheckCircle className="w-4 h-4 text-green-400" />
                  <span className="text-sm font-medium">{benefit}</span>
                </div>
              ))}
            </div>
            
            {/* Hero Buttons - Uniform Size with Filled Icons and Aligned Text */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 max-w-4xl mx-auto">
              <Link to="/takbyte" className="bg-white text-blue-600 px-4 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex flex-col items-center justify-center space-y-2 min-h-[80px] text-center">
                <Home className="w-6 h-6 text-purple-500 fill-current" />
                <span className="text-sm">Takbyte</span>
              </Link>
              <Link to="/varmepumpar" className="bg-white text-blue-600 px-4 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex flex-col items-center justify-center space-y-2 min-h-[80px] text-center">
                <Thermometer className="w-6 h-6 text-red-500 fill-current" />
                <span className="text-sm">Värmepumpar</span>
              </Link>
              <Link to="/badrumsrenovering" className="bg-white text-blue-600 px-4 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex flex-col items-center justify-center space-y-2 min-h-[80px] text-center">
                <Bath className="w-6 h-6 text-teal-500 fill-current" />
                <span className="text-sm">Badrumsrenovering</span>
              </Link>
              <Link to="/fonster" className="bg-white text-blue-600 px-4 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex flex-col items-center justify-center space-y-2 min-h-[80px] text-center">
                <img 
                  src="/window.png" 
                  alt="Fönster & Dörrar" 
                  className="w-6 h-6"
                />
                <span className="text-sm">Fönster & Dörrar</span>
              </Link>
              <Link to="/solceller" className="bg-white text-blue-600 px-4 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex flex-col items-center justify-center space-y-2 min-h-[80px] text-center">
                <Sun className="w-6 h-6 text-yellow-500 fill-current" />
                <span className="text-sm">Solceller</span>
              </Link>
              <Link to="/dranering" className="bg-white text-blue-600 px-4 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors flex flex-col items-center justify-center space-y-2 min-h-[80px] text-center">
                <Droplets className="w-6 h-6 text-blue-500 fill-current" />
                <span className="text-sm">Dränering</span>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Visual Services Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Välj din tjänst
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Klicka på bilden för den tjänst du behöver hjälp med och få kostnadsfria offerter redan idag.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {visualServices.map((service, index) => (
              <Link 
                key={index}
                to={service.link}
                className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 aspect-[4/3]"
              >
                <img 
                  src={service.image} 
                  alt={service.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  onError={(e) => {
                    console.log(`Failed to load image: ${service.image}`);
                    // Fallback to a solid color background if image fails
                    e.currentTarget.style.display = 'none';
                    e.currentTarget.parentElement!.style.backgroundColor = '#6B7280';
                  }}
                  onLoad={() => {
                    console.log(`Successfully loaded image: ${service.image}`);
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent"></div>
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-blue-200 transition-colors">
                    {service.title}
                  </h3>
                  <div className="flex items-center text-white/90 group-hover:text-blue-200 transition-colors">
                    <span className="text-sm font-medium">Jämför offerter</span>
                    <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works Section - Updated to horizontal layout */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Så här fungerar det
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Enkelt och smidigt i tre steg
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                step: '1',
                title: 'Berätta om ditt projekt',
                description: 'Fyll i vårt enkla formulär och beskriv vad du behöver hjälp med.'
              },
              {
                step: '2',
                title: 'Vi matchar dig med företag',
                description: 'Vi hittar upp till 3 kvalificerade företag som passar dina behov.'
              },
              {
                step: '3',
                title: 'Jämför och välj',
                description: 'Jämför offerterna och välj det företag som passar dig bäst.'
              }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="flex-shrink-0 w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center text-2xl font-bold mx-auto mb-6">
                  {item.step}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">{item.title}</h3>
                  <p className="text-gray-600 text-lg leading-relaxed">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-16 bg-gray-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-12">
          <div className="text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Våra kunder säger det bäst
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Över 10 000 nöjda kunder har använt Fixvia för sina hemförbättringsprojekt
            </p>
          </div>
        </div>

        {/* Scrolling testimonials */}
        <div className="relative">
          <div className="flex animate-scroll space-x-6">
            {/* First set of testimonials */}
            {testimonials.map((testimonial, index) => (
              <div key={index} className="flex-shrink-0 w-80 bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 leading-relaxed">
                  "{testimonial.text}"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold mr-3">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{testimonial.name}</p>
                    <p className="text-sm text-gray-600">{testimonial.location}</p>
                  </div>
                </div>
              </div>
            ))}
            {/* Duplicate set for seamless loop */}
            {testimonials.map((testimonial, index) => (
              <div key={`duplicate-${index}`} className="flex-shrink-0 w-80 bg-white rounded-xl p-6 shadow-lg">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 leading-relaxed">
                  "{testimonial.text}"
                </p>
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white font-semibold mr-3">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{testimonial.name}</p>
                    <p className="text-sm text-gray-600">{testimonial.location}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section with Image */}
      <section className="py-20 bg-blue-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Image */}
            <div className="relative">
              <img 
                src="/bild-lycklig-familj-hemsida.jpg" 
                alt="Lycklig familj hemma" 
                className="rounded-xl shadow-2xl w-full h-auto object-cover"
              />
              <div className="absolute inset-0 bg-blue-900 bg-opacity-20 rounded-xl"></div>
            </div>

            {/* Stats Content */}
            <div className="text-center lg:text-left">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                Fixvia i siffror
              </h2>
              <p className="text-xl text-blue-100 mb-12">
                Våra resultat talar för sig själva
              </p>

              <div className="grid grid-cols-1 gap-8">
                {stats.map((stat, index) => (
                  <div key={index} className="text-center lg:text-left">
                    <div className="mb-2">
                      <AnimatedCounter 
                        end={stat.number} 
                        suffix={stat.suffix}
                        duration={2500}
                      />
                    </div>
                    <div className="text-blue-100 font-medium text-lg">
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;