import React, { useState } from 'react';
import { Building2, Send, CheckCircle, Users, TrendingUp, Shield, Star, Phone, Mail, ArrowRight } from 'lucide-react';
import FormField from '../components/FormField';

const ConnectCompany = () => {
  const [formData, setFormData] = useState({
    companyName: '',
    contactPerson: '',
    email: '',
    phone: '',
    website: '',
    services: '',
    coverage: '',
    experience: '',
    employees: '',
    certifications: '',
    description: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Company application submitted:', formData);
    alert('Tack för din ansökan! Vi kommer att kontakta dig inom kort för att diskutera samarbetet.');
  };

  const updateField = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const benefits = [
    {
      icon: Users,
      title: 'Kvalificerade leads',
      description: 'Vi skickar endast kunder som är redo att köpa direkt till dig'
    },
    {
      icon: TrendingUp,
      title: 'Betala endast för resultat',
      description: 'Du betalar bara för leads som vi har verifierat är genuint intresserade'
    },
    {
      icon: Star,
      title: 'Marknadsföring',
      description: 'Exponering på vår plattform utan extra kostnad'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-500 rounded-full mb-6">
            <Building2 className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Anslut ditt företag
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Bli en del av Sveriges ledande nätverk för hemförbättringsföretag. 
            Få tillgång till kvalificerade kunder och väx ditt företag.
          </p>
        </div>

        {/* Benefits */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {benefits.map((benefit, index) => {
            const IconComponent = benefit.icon;
            return (
              <div key={index} className="bg-white rounded-xl shadow-lg p-6 text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-100 rounded-lg mb-4">
                  <IconComponent className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{benefit.title}</h3>
                <p className="text-gray-600">{benefit.description}</p>
              </div>
            );
          })}
        </div>

        {/* Requirements */}
        <div className="bg-white rounded-xl shadow-lg p-8 mb-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Krav för att bli partner</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Grundläggande krav</h3>
              <ul className="space-y-3">
                {[
                  'Registrerat företag i Sverige',
                  'F-skattesedel och giltiga försäkringar',
                  'Minst 2 års branschexperiens',
                  'Goda referenser från tidigare kunder'
                ].map((requirement, index) => (
                  <li key={index} className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-gray-700">{requirement}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Kvalitetskrav</h3>
              <ul className="space-y-3">
                {[
                  'Professionell kundservice',
                  'Tydliga offerter och prisuppgifter',
                  'Garantier på utfört arbete',
                  'Miljömedvetenhet och hållbarhet'
                ].map((requirement, index) => (
                  <li key={index} className="flex items-center space-x-3">
                    <CheckCircle className="w-5 h-5 text-green-500 flex-shrink-0" />
                    <span className="text-gray-700">{requirement}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Application Form */}
        <div className="bg-white rounded-xl shadow-lg p-8 md:p-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Ansök om partnerskap</h2>
          
          <form onSubmit={handleSubmit} className="space-y-8">
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Företagsinformation</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  label="Företagsnamn"
                  type="text"
                  name="companyName"
                  value={formData.companyName}
                  onChange={(value) => updateField('companyName', value)}
                  placeholder="Ditt företags namn"
                  required
                />

                <FormField
                  label="Kontaktperson"
                  type="text"
                  name="contactPerson"
                  value={formData.contactPerson}
                  onChange={(value) => updateField('contactPerson', value)}
                  placeholder="Namn på kontaktperson"
                  required
                />

                <FormField
                  label="E-post"
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={(value) => updateField('email', value)}
                  placeholder="företag@exempel.se"
                  required
                />

                <FormField
                  label="Telefonnummer"
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={(value) => updateField('phone', value)}
                  placeholder="08-123 456 789"
                  required
                />

                <FormField
                  label="Webbsida"
                  type="text"
                  name="website"
                  value={formData.website}
                  onChange={(value) => updateField('website', value)}
                  placeholder="www.dittföretag.se"
                />

                <FormField
                  label="Antal anställda"
                  type="select"
                  name="employees"
                  value={formData.employees}
                  onChange={(value) => updateField('employees', value)}
                  options={[
                    { value: '1-5', label: '1-5 anställda' },
                    { value: '6-15', label: '6-15 anställda' },
                    { value: '16-50', label: '16-50 anställda' },
                    { value: '50+', label: 'Över 50 anställda' }
                  ]}
                  required
                />
              </div>
            </div>

            <hr className="border-gray-200" />

            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-6">Tjänster och verksamhet</h3>
              
              <FormField
                label="Vilka tjänster erbjuder ni?"
                type="radio"
                name="services"
                value={formData.services}
                onChange={(value) => updateField('services', value)}
                options={[
                  { value: 'windows-doors', label: 'Fönster & Dörrar' },
                  { value: 'solar', label: 'Solceller' },
                  { value: 'charging', label: 'Laddboxar' },
                  { value: 'heatpumps', label: 'Värmepumpar' },
                  { value: 'roof', label: 'Takbyte' },
                  { value: 'insulation', label: 'Isolering' },
                  { value: 'multiple', label: 'Flera tjänster' }
                ]}
                required
              />

              <FormField
                label="Geografisk täckning"
                type="select"
                name="coverage"
                value={formData.coverage}
                onChange={(value) => updateField('coverage', value)}
                options={[
                  { value: 'local', label: 'Lokal (en kommun)' },
                  { value: 'regional', label: 'Regional (flera kommuner)' },
                  { value: 'county', label: 'Länsvis' },
                  { value: 'national', label: 'Nationell täckning' }
                ]}
                required
              />

              <FormField
                label="Branschexperiens"
                type="select"
                name="experience"
                value={formData.experience}
                onChange={(value) => updateField('experience', value)}
                options={[
                  { value: '2-5', label: '2-5 år' },
                  { value: '6-10', label: '6-10 år' },
                  { value: '11-20', label: '11-20 år' },
                  { value: '20+', label: 'Över 20 år' }
                ]}
                required
              />

              <FormField
                label="Certifieringar och auktorisationer"
                type="text"
                name="certifications"
                value={formData.certifications}
                onChange={(value) => updateField('certifications', value)}
                placeholder="T.ex. ROT-godkänd, Elinstallationsföretag, etc."
              />

              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-700 mb-3">
                  Beskriv ert företag och era styrkor
                  <span className="text-red-500 ml-1">*</span>
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => updateField('description', e.target.value)}
                  placeholder="Berätta om ert företag, era specialiteter och vad som gör er unika..."
                  rows={4}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
            >
              <Send className="w-5 h-5" />
              <span>Skicka ansökan</span>
            </button>

            <p className="text-sm text-gray-500 text-center">
              Genom att skicka ansökan godkänner du våra villkor för partnerskap. 
              Vi behandlar din ansökan inom 5 arbetsdagar.
            </p>
          </form>
        </div>

        {/* Process */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-12">Så här går det till</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              {
                step: '1',
                title: 'Ansök',
                description: 'Fyll i ansökningsformuläret med företagsinformation'
              },
              {
                step: '2',
                title: 'Granskning',
                description: 'Vi granskar din ansökan och kontrollerar referenser'
              },
              {
                step: '3',
                title: 'Godkännande',
                description: 'Vid godkännande får du tillgång till vår plattform'
              },
              {
                step: '4',
                title: 'Börja ta emot leads',
                description: 'Få kvalificerade förfrågningar från potentiella kunder'
              }
            ].map((item, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 bg-blue-600 text-white rounded-full text-lg font-bold mb-4">
                  {item.step}
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-gray-600">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConnectCompany;