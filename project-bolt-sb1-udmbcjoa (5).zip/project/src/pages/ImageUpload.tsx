import React, { useState } from 'react';
import { Upload, CheckCircle, Camera, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const ImageUpload = () => {
  const [uploadedImage, setUploadedImage] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isUploaded, setIsUploaded] = useState(false);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setUploadedImage(file);
    }
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && (file.type === 'image/jpeg' || file.type === 'image/png')) {
      setUploadedImage(file);
    }
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
  };

  const submitImage = async () => {
    if (!uploadedImage) return;

    setIsUploading(true);

    try {
      // Facebook Pixel tracking
      if (typeof window !== 'undefined' && (window as any).fbq) {
        (window as any).fbq('track', 'Lead', {
          content_name: 'Image Upload',
          content_category: 'Home Improvement',
          value: 1,
          currency: 'SEK'
        });
      }

      // Send to Make webhook
      const webhookData = {
        timestamp: new Date().toISOString(),
        source: 'fixvia.se/upload',
        type: 'image_only_upload',
        hasImage: true,
        imageName: uploadedImage.name,
        imageSize: uploadedImage.size
      };

      // Replace with your actual webhook URL
      const webhookUrl = 'https://hook.eu2.make.com/YOUR_WEBHOOK_ID';
      const response = await fetch(webhookUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(webhookData)
      });

      if (response.ok) {
        setIsUploaded(true);
      } else {
        throw new Error('Webhook submission failed');
      }
    } catch (error) {
      console.error('Error uploading image:', error);
      // Show success even if webhook fails
      setIsUploaded(true);
    } finally {
      setIsUploading(false);
    }
  };

  if (isUploaded) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-lg p-8 text-center">
            <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-10 h-10 text-white" />
            </div>
            
            <h1 className="text-3xl font-bold text-gray-900 mb-4">
              Tack för din bild!
            </h1>
            
            <p className="text-lg text-gray-600 mb-6">
              Vi har tagit emot din bild och kommer att höra av oss snart med din visualisering.
            </p>
            
            <div className="bg-blue-50 p-6 rounded-lg mb-8">
              <h3 className="font-semibold text-blue-900 mb-2">Vad händer nu?</h3>
              <ul className="text-blue-800 text-sm space-y-1 text-left">
                <li>✓ Vi skapar din personliga visualisering</li>
                <li>✓ Du får resultatet via mejl inom kort</li>
                <li>✓ Vi skickar kostnadsfria offerter från verifierade företag</li>
                <li>✓ En expert kontaktar dig inom 24 timmar</li>
              </ul>
            </div>

            <Link
              to="/"
              className="inline-flex items-center space-x-2 bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
            >
              <span>Tillbaka till startsidan</span>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Link */}
        <Link 
          to="/" 
          className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-8 font-medium transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Tillbaka till startsidan
        </Link>

        {/* Main Content */}
        <div className="bg-white rounded-xl shadow-lg p-8">
          {/* Icon */}
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Camera className="w-8 h-8 text-green-600" />
            </div>
          </div>

          <div className="text-center mb-8">
            <h1 className="text-2xl md:text-3xl font-bold text-gray-900 mb-4">
              Ladda upp en bild på ditt hus
            </h1>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Vi laddar upp din bild till en säker bildserver för att skapa din visualisering.
            </p>
          </div>

          <div className="space-y-6 max-w-2xl mx-auto">
            <div 
              className="border-2 border-dashed border-gray-300 rounded-xl p-12 text-center hover:border-blue-400 transition-colors bg-gray-50"
              onDrop={handleDrop}
              onDragOver={handleDragOver}
            >
              <input
                type="file"
                accept="image/jpeg,image/png"
                onChange={handleImageUpload}
                className="hidden"
                id="image-upload"
              />
              <label htmlFor="image-upload" className="cursor-pointer">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Upload className="w-8 h-8 text-blue-600" />
                </div>
                <p className="text-lg font-medium text-gray-700 mb-2">
                  {uploadedImage ? uploadedImage.name : 'Dra och släpp din bild här'}
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  eller klicka för att välja fil
                </p>
                <p className="text-xs text-gray-400">
                  JPG eller PNG, max 10MB
                </p>
              </label>
            </div>

            {uploadedImage && (
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <div className="flex items-center space-x-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <div>
                    <p className="text-green-800 font-medium">Bild vald: {uploadedImage.name}</p>
                    <p className="text-green-600 text-sm">
                      Storlek: {(uploadedImage.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                </div>
              </div>
            )}

            <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
              <p className="text-yellow-800 text-sm">
                <strong>Tips:</strong> Välj en bild tagen framifrån huset för bästa resultat. 
                Bilden hjälper oss att skapa en mer exakt visualisering.
              </p>
            </div>

            <button
              onClick={submitImage}
              disabled={!uploadedImage || isUploading}
              className="w-full bg-green-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-green-700 transition-colors flex items-center justify-center space-x-2 text-lg disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isUploading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  <span>Laddar upp...</span>
                </>
              ) : (
                <>
                  <Upload className="w-5 h-5" />
                  <span>Ladda upp bild</span>
                </>
              )}
            </button>

            <p className="text-sm text-gray-500 text-center">
              Genom att ladda upp bilden godkänner du att vi använder den för att skapa din visualisering. 
              Vi delar aldrig dina bilder med tredje part.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageUpload;