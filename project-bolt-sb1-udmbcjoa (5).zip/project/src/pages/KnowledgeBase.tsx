import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, BookOpen, Clock, User, ArrowRight } from 'lucide-react';

const KnowledgeBase = () => {
  const articles = [
    {
      id: 1,
      title: 'Guide: Så väljer du rätt fönster för ditt hem',
      excerpt: 'Allt du behöver veta om energieffektivitet, material och stilar när du ska byta fönster.',
      category: 'Fönster & Dörrar',
      readTime: '8 min',
      author: 'Anna Lindström',
      image: 'https://images.pexels.com/photos/1396122/pexels-photo-1396122.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop'
    },
    {
      id: 2,
      title: 'Värmepumpar: Komplett guide för villaägare',
      excerpt: 'Jämförelse av olika värmepumpstyper, installation och vad du kan spara på elräkningen.',
      category: 'Värmepumpar',
      readTime: '12 min',
      author: 'Erik Johansson',
      image: 'https://images.pexels.com/photos/8293778/pexels-photo-8293778.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop'
    },
    {
      id: 3,
      title: 'Solceller: Lönar det sig för ditt hus?',
      excerpt: 'Kalkylera lönsamheten, förstå olika tekniker och få tips för optimal placering.',
      category: 'Solceller',
      readTime: '10 min',
      author: 'Maria Andersson',
      image: 'https://images.pexels.com/photos/9875414/pexels-photo-9875414.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop'
    },
    {
      id: 4,
      title: 'Takbyte: När är det dags och vad kostar det?',
      excerpt: 'Tecken på att taket behöver bytas, olika material och vad du kan förvänta dig att betala.',
      category: 'Takbyte',
      readTime: '6 min',
      author: 'Lars Nilsson',
      image: 'https://images.pexels.com/photos/1396132/pexels-photo-1396132.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop'
    },
    {
      id: 5,
      title: 'Badrumsrenovering: Planering och genomförande',
      excerpt: 'Steg-för-steg guide för att renovera ditt badrum utan stress och överraskningar.',
      category: 'Badrumsrenovering',
      readTime: '15 min',
      author: 'Petra Karlsson',
      image: 'https://images.pexels.com/photos/1454804/pexels-photo-1454804.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop'
    },
    {
      id: 6,
      title: 'Dränering: Skydda ditt hus mot fukt',
      excerpt: 'Allt om dränering runt husgrunden, tecken på problem och moderna lösningar.',
      category: 'Dränering',
      readTime: '9 min',
      author: 'Gunnar Svensson',
      image: 'https://images.pexels.com/photos/1108572/pexels-photo-1108572.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop'
    }
  ];

  const categories = [
    'Alla kategorier',
    'Fönster & Dörrar',
    'Värmepumpar',
    'Solceller',
    'Takbyte',
    'Badrumsrenovering',
    'Dränering'
  ];

  const [selectedCategory, setSelectedCategory] = React.useState('Alla kategorier');

  const filteredArticles = selectedCategory === 'Alla kategorier' 
    ? articles 
    : articles.filter(article => article.category === selectedCategory);

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Link */}
        <Link 
          to="/" 
          className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-8 font-medium transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Tillbaka till startsidan
        </Link>

        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-500 rounded-full mb-6">
            <BookOpen className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Kunskapsbank
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Expertguider och tips för alla dina hemförbättringsprojekt. 
            Lär dig allt du behöver veta innan du börjar.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((category) => (
            <button
              key={category}
              onClick={() => setSelectedCategory(category)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                selectedCategory === category
                  ? 'bg-blue-600 text-white'
                  : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-200'
              }`}
            >
              {category}
            </button>
          ))}
        </div>

        {/* Articles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredArticles.map((article) => (
            <article key={article.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
              <img 
                src={article.image} 
                alt={article.title}
                className="w-full h-48 object-cover"
              />
              <div className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-sm font-medium text-blue-600 bg-blue-100 px-2 py-1 rounded">
                    {article.category}
                  </span>
                  <div className="flex items-center text-gray-500 text-sm">
                    <Clock className="w-4 h-4 mr-1" />
                    {article.readTime}
                  </div>
                </div>
                
                <h3 className="text-xl font-bold text-gray-900 mb-3 line-clamp-2">
                  {article.title}
                </h3>
                
                <p className="text-gray-600 mb-4 line-clamp-3">
                  {article.excerpt}
                </p>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-gray-500 text-sm">
                    <User className="w-4 h-4 mr-1" />
                    {article.author}
                  </div>
                  
                  <button className="flex items-center text-blue-600 hover:text-blue-800 font-medium text-sm transition-colors">
                    Läs mer
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </button>
                </div>
              </div>
            </article>
          ))}
        </div>

        {/* CTA Section */}
        <div className="mt-16 bg-blue-600 rounded-xl p-8 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Behöver du hjälp med ditt projekt?
          </h2>
          <p className="text-blue-100 mb-6 max-w-2xl mx-auto">
            Våra experter hjälper dig att hitta rätt lösning och jämföra offerter från verifierade företag.
          </p>
          <Link 
            to="/"
            className="inline-flex items-center bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
          >
            Få kostnadsfria offerter
            <ArrowRight className="w-4 h-4 ml-2" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default KnowledgeBase;