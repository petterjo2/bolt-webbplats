import React, { useState } from 'react';
import FormLayout from '../components/FormLayout';
import FormField from '../components/FormField';
import { Shield, Send } from 'lucide-react';

const InsulationForm = () => {
  const [formData, setFormData] = useState({
    // Qualifying questions
    whatToInsulate: '',
    houseType: '',
    area: '',
    problems: '',
    // Contact fields
    name: '',
    email: '',
    phone: '',
    address: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Tack för din förfrågan! Vi kommer att kontakta dig inom kort.');
  };

  const updateField = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <FormLayout
      title="Isolering"
      description="Få kostnadsfria offerter för isolering. Förbättra energieffektiviteten och minska dina energikostnader."
      icon={Shield}
      iconColor="bg-orange-500"
    >
      <form onSubmit={handleSubmit} className="space-y-8">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Berätta om ditt projekt</h2>
          
          <FormField
            label="Vad vill du isolera?"
            type="radio"
            name="whatToInsulate"
            value={formData.whatToInsulate}
            onChange={(value) => updateField('whatToInsulate', value)}
            options={[
              { value: 'attic', label: 'Vind' },
              { value: 'walls', label: 'Väggar' },
              { value: 'crawlspace', label: 'Krypgrund' },
              { value: 'basement', label: 'Källare' },
              { value: 'multiple', label: 'Flera områden' }
            ]}
            required
          />

          <FormField
            label="Typ av bostad?"
            type="radio"
            name="houseType"
            value={formData.houseType}
            onChange={(value) => updateField('houseType', value)}
            options={[
              { value: 'villa', label: 'Villa' },
              { value: 'townhouse', label: 'Radhus' },
              { value: 'apartment', label: 'Lägenhet' },
              { value: 'summerhouse', label: 'Fritidshus' },
              { value: 'other', label: 'Annat' }
            ]}
            required
          />

          <FormField
            label="Ungefärlig yta (kvm)"
            type="select"
            name="area"
            value={formData.area}
            onChange={(value) => updateField('area', value)}
            options={[
              { value: 'under-50', label: 'Under 50 kvm' },
              { value: '50-100', label: '50-100 kvm' },
              { value: '100-150', label: '100-150 kvm' },
              { value: '150-200', label: '150-200 kvm' },
              { value: 'over-200', label: 'Över 200 kvm' },
              { value: 'unknown', label: 'Vet ej' }
            ]}
            required
          />

          <FormField
            label="Märker du kallras, drag eller höga elräkningar?"
            type="radio"
            name="problems"
            value={formData.problems}
            onChange={(value) => updateField('problems', value)}
            options={[
              { value: 'yes-all', label: 'Ja, alla problemen' },
              { value: 'yes-some', label: 'Ja, några av problemen' },
              { value: 'no', label: 'Nej' },
              { value: 'unsure', label: 'Osäker' }
            ]}
            required
          />
        </div>

        <hr className="border-gray-200" />

        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Dina kontaktuppgifter</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <FormField
              label="Namn"
              type="text"
              name="name"
              value={formData.name}
              onChange={(value) => updateField('name', value)}
              placeholder="Ditt för- och efternamn"
              required
            />

            <FormField
              label="E-post"
              type="email"
              name="email"
              value={formData.email}
              onChange={(value) => updateField('email', value)}
              placeholder="din@email.se"
              required
            />

            <FormField
              label="Telefonnummer"
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={(value) => updateField('phone', value)}
              placeholder="070-123 45 67"
              required
            />

            <FormField
              label="Adress"
              type="text"
              name="address"
              value={formData.address}
              onChange={(value) => updateField('address', value)}
              placeholder="Gata, Postnummer, Ort"
              required
            />
          </div>
        </div>

        <button
          type="submit"
          className="w-full bg-orange-600 text-white px-8 py-4 rounded-lg font-semibold hover:bg-orange-700 transition-colors flex items-center justify-center space-x-2"
        >
          <Send className="w-5 h-5" />
          <span>Skicka förfrågan</span>
        </button>

        <p className="text-sm text-gray-500 text-center">
          Genom att skicka förfrågan godkänner du att vi kontaktar dig med offerter. 
          Kostnadsfritt och utan förpliktelser.
        </p>
      </form>
    </FormLayout>
  );
};

export default InsulationForm;