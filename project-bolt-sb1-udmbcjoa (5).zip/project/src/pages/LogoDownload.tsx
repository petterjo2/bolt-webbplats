import React from 'react';
import { Download, ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';

const LogoDownload = () => {
  const downloadSVG = () => {
    const svgContent = `<svg width="64" height="64" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="mainGradient" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" style="stop-color:#3B82F6;stop-opacity:1" />
      <stop offset="100%" style="stop-color:#1D4ED8;stop-opacity:1" />
    </linearGradient>
    <filter id="shadow" x="-50%" y="-50%" width="200%" height="200%">
      <feDropShadow dx="0" dy="4" stdDeviation="3" flood-color="rgba(0,0,0,0.25)"/>
    </filter>
  </defs>
  
  <!-- Main circle -->
  <circle cx="32" cy="32" r="28" fill="url(#mainGradient)" filter="url(#shadow)"/>
  
  <!-- Inner white dot -->
  <circle cx="32" cy="32" r="10" fill="white"/>
  
  <!-- Accent dot -->
  <circle cx="44" cy="20" r="8" fill="#60A5FA" opacity="0.8"/>
</svg>`;

    const blob = new Blob([svgContent], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'fixvia-logo-icon.svg';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const downloadPNG = (size: number) => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d')!;
    canvas.width = size;
    canvas.height = size;

    // Clear with transparent background
    ctx.clearRect(0, 0, size, size);

    const centerX = size / 2;
    const centerY = size / 2;
    const mainRadius = size * 0.4;
    const innerRadius = size * 0.15;
    const accentRadius = size * 0.12;

    // Create gradient for main circle
    const gradient = ctx.createLinearGradient(0, 0, size, size);
    gradient.addColorStop(0, '#3B82F6');
    gradient.addColorStop(1, '#1D4ED8');

    // Draw shadow
    ctx.shadowColor = 'rgba(0, 0, 0, 0.25)';
    ctx.shadowBlur = size * 0.05;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = size * 0.02;

    // Draw main circle
    ctx.beginPath();
    ctx.arc(centerX, centerY, mainRadius, 0, 2 * Math.PI);
    ctx.fillStyle = gradient;
    ctx.fill();

    // Reset shadow
    ctx.shadowColor = 'transparent';
    ctx.shadowBlur = 0;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 0;

    // Draw inner white dot
    ctx.beginPath();
    ctx.arc(centerX, centerY, innerRadius, 0, 2 * Math.PI);
    ctx.fillStyle = 'white';
    ctx.fill();

    // Draw accent dot
    ctx.globalAlpha = 0.8;
    ctx.beginPath();
    ctx.arc(centerX + mainRadius * 0.6, centerY - mainRadius * 0.6, accentRadius, 0, 2 * Math.PI);
    ctx.fillStyle = '#60A5FA';
    ctx.fill();
    ctx.globalAlpha = 1;

    // Download
    const link = document.createElement('a');
    link.download = `fixvia-logo-icon-${size}px.png`;
    link.href = canvas.toDataURL('image/png');
    link.click();
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Link */}
        <Link 
          to="/" 
          className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-8 font-medium transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Tillbaka till startsidan
        </Link>

        <div className="bg-white rounded-xl shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-6 text-center">
            Ladda ner Fixvia logotyp
          </h1>
          
          <p className="text-lg text-gray-600 text-center mb-8">
            Här kan du ladda ner bara loggan (cirkeln) utan text - perfekt för sociala medier!
          </p>

          {/* Logo Preview */}
          <div className="flex justify-center mb-12">
            <div className="bg-gray-100 p-8 rounded-xl">
              <div className="relative">
                {/* Main circle with gradient */}
                <div className="w-24 h-24 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full flex items-center justify-center shadow-lg">
                  <div className="w-9 h-9 bg-white rounded-full"></div>
                </div>
                {/* Accent dot */}
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-blue-400 rounded-full opacity-80"></div>
              </div>
            </div>
          </div>

          {/* Download Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* SVG Download */}
            <div className="bg-blue-50 p-6 rounded-xl border border-blue-200">
              <h3 className="text-xl font-bold text-blue-900 mb-3">SVG Format</h3>
              <p className="text-blue-700 mb-4 text-sm">
                Vektorformat - skalbar utan kvalitetsförlust. Perfekt för webb och tryck.
              </p>
              <button
                onClick={downloadSVG}
                className="w-full bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center space-x-2"
              >
                <Download className="w-5 h-5" />
                <span>Ladda ner SVG</span>
              </button>
            </div>

            {/* PNG Downloads */}
            <div className="bg-green-50 p-6 rounded-xl border border-green-200">
              <h3 className="text-xl font-bold text-green-900 mb-3">PNG Format</h3>
              <p className="text-green-700 mb-4 text-sm">
                Transparent bakgrund - perfekt för sociala medier och annonser.
              </p>
              <div className="space-y-2">
                {[
                  { size: 512, label: 'Hög kvalitet (512px)' },
                  { size: 256, label: 'Medium (256px)' },
                  { size: 128, label: 'Liten (128px)' }
                ].map((option) => (
                  <button
                    key={option.size}
                    onClick={() => downloadPNG(option.size)}
                    className="w-full bg-green-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-700 transition-colors flex items-center justify-center space-x-2 text-sm"
                  >
                    <Download className="w-4 h-4" />
                    <span>{option.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Usage Guidelines */}
          <div className="mt-12 bg-gray-50 p-6 rounded-xl">
            <h3 className="text-lg font-bold text-gray-900 mb-4">📋 Användningsriktlinjer</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">✅ Rekommenderat:</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Använd på sociala medier (Facebook, Instagram)</li>
                  <li>• Profilbilder och avatarer</li>
                  <li>• App-ikoner och favicons</li>
                  <li>• Visitkort och brevpapper</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 mb-2">⚠️ Viktigt att tänka på:</h4>
                <ul className="text-sm text-gray-600 space-y-1">
                  <li>• Behåll proportionerna</li>
                  <li>• Använd på ljus bakgrund för bästa kontrast</li>
                  <li>• Minsta storlek: 32px för webbanvändning</li>
                  <li>• SVG för skalbarhet, PNG för kompatibilitet</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Color Information */}
          <div className="mt-8 bg-blue-50 p-6 rounded-xl border border-blue-200">
            <h3 className="text-lg font-bold text-blue-900 mb-4">🎨 Färginformation</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-700 rounded-full mx-auto mb-2"></div>
                <p className="text-sm font-medium text-blue-900">Huvudfärg</p>
                <p className="text-xs text-blue-700">#3B82F6 → #1D4ED8</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-white border-2 border-gray-200 rounded-full mx-auto mb-2"></div>
                <p className="text-sm font-medium text-blue-900">Inre cirkel</p>
                <p className="text-xs text-blue-700">#FFFFFF</p>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-blue-400 rounded-full mx-auto mb-2 opacity-80"></div>
                <p className="text-sm font-medium text-blue-900">Accent</p>
                <p className="text-xs text-blue-700">#60A5FA</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LogoDownload;