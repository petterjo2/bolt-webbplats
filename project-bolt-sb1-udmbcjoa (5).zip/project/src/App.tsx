import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import HomePage from './pages/HomePage';
import WindowsDoorsForm from './pages/WindowsDoorsForm';
import SolarPanelsQuiz from './pages/SolarPanelsQuiz';
import DrainageQuiz from './pages/DrainageQuiz';
import HeatPumpsQuiz from './pages/HeatPumpsQuiz';
import RoofReplacementQuiz from './pages/RoofReplacementQuiz';
import BathroomRenovationQuiz from './pages/BathroomRenovationQuiz';
import KnowledgeBase from './pages/KnowledgeBase';
import ConnectCompany from './pages/ConnectCompany';
import AboutUs from './pages/AboutUs';
import LogoDownload from './pages/LogoDownload';
import WindowsDoorsQuiz from './pages/WindowsDoorsQuiz';
import ImageUpload from './pages/ImageUpload';
import Footer from './components/Footer';
import './index.css';

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <Header />
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/fonster" element={<WindowsDoorsQuiz />} />
            <Route path="/fonster-dorrar" element={<WindowsDoorsQuiz />} />
            <Route path="/solceller" element={<SolarPanelsQuiz />} />
            <Route path="/dranering" element={<DrainageQuiz />} />
            <Route path="/varmepumpar" element={<HeatPumpsQuiz />} />
            <Route path="/takbyte" element={<RoofReplacementQuiz />} />
            <Route path="/badrumsrenovering" element={<BathroomRenovationQuiz />} />
            <Route path="/kunskapsbank" element={<KnowledgeBase />} />
            <Route path="/anslut-foretag" element={<ConnectCompany />} />
            <Route path="/om-oss" element={<AboutUs />} />
            <Route path="/ladda-ner-logo" element={<LogoDownload />} />
            <Route path="/upload" element={<ImageUpload />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;