import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, CheckCircle } from 'lucide-react';

interface FormLayoutProps {
  title: string;
  description: string;
  icon: React.ComponentType<{ className?: string }>;
  children: React.ReactNode;
  iconColor?: string;
}

const FormLayout: React.FC<FormLayoutProps> = ({ 
  title, 
  description, 
  icon: IconComponent, 
  children,
  iconColor = 'bg-blue-500'
}) => {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Link */}
        <Link 
          to="/" 
          className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-8 font-medium transition-colors"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Tillbaka till startsidan
        </Link>

        {/* Header */}
        <div className="text-center mb-12">
          <div className={`inline-flex items-center justify-center w-20 h-20 ${iconColor} rounded-full mb-6`}>
            <IconComponent className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            {title}
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            {description}
          </p>
        </div>

        {/* Benefits */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {[
            'Kostnadsfritt',
            'Upp till 3 offerter',
            'Inga förpliktelser',
            'Verifierade företag'
          ].map((benefit, index) => (
            <div key={index} className="flex items-center space-x-2 bg-green-100 text-green-800 px-4 py-2 rounded-full">
              <CheckCircle className="w-4 h-4" />
              <span className="text-sm font-medium">{benefit}</span>
            </div>
          ))}
        </div>

        {/* Form Content */}
        <div className="bg-white rounded-xl shadow-lg p-8 md:p-12">
          {children}
        </div>
      </div>
    </div>
  );
};

export default FormLayout;