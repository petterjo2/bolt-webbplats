import React from 'react';
import { Instagram, Facebook, Youtube, Linkedin, Phone, Mail, MapPin, Download } from 'lucide-react';
import { Link } from 'react-router-dom';

const FixviaLogo = () => (
  <div className="flex items-center space-x-2">
    <div className="relative">
      {/* Main circle with gradient */}
      <div className="w-6 h-6 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center">
        <div className="w-2 h-2 bg-white rounded-full"></div>
      </div>
      {/* Accent dot */}
      <div className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-blue-300 rounded-full opacity-80"></div>
    </div>
    <span className="text-xl font-bold text-white">Fixvia</span>
  </div>
);

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div className="space-y-4">
            <FixviaLogo />
            <p className="text-gray-300 text-sm">
              Vi hjälper villaägare att hitta bästa leverantörerna för hemförbättring. 
              Kostnadsfritt och enkelt.
            </p>
            <Link 
              to="/ladda-ner-logo"
              className="inline-flex items-center space-x-2 text-blue-400 hover:text-blue-300 transition-colors text-sm"
            >
              <Download className="w-4 h-4" />
              <span>Ladda ner logotyp</span>
            </Link>
          </div>

          {/* Services */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Våra tjänster</h3>
            <ul className="space-y-2 text-sm text-gray-300">
              <li><a href="/takbyte" className="hover:text-blue-400 transition-colors">Takbyte</a></li>
              <li><a href="/varmepumpar" className="hover:text-blue-400 transition-colors">Värmepumpar</a></li>
              <li><a href="/badrumsrenovering" className="hover:text-blue-400 transition-colors">Badrumsrenovering</a></li>
              <li><a href="/fonster" className="hover:text-blue-400 transition-colors">Fönster & Dörrar</a></li>
              <li><a href="/solceller" className="hover:text-blue-400 transition-colors">Solceller</a></li>
              <li><a href="/dranering" className="hover:text-blue-400 transition-colors">Dränering</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Kontakt</h3>
            <div className="space-y-2 text-sm text-gray-300">
              <div className="flex items-center space-x-2">
                <Phone className="w-4 h-4" />
                <span>08-123 456 789</span>
              </div>
              <div className="flex items-center space-x-2">
                <Mail className="w-4 h-4" />
                <span>info@fixvia.se</span>
              </div>
              <div className="flex items-center space-x-2">
                <MapPin className="w-4 h-4" />
                <span>Stockholm, Sverige</span>
              </div>
            </div>
          </div>

          {/* Social Media */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Följ oss</h3>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors">
                <Instagram className="w-6 h-6" />
              </a>
              <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors">
                <Facebook className="w-6 h-6" />
              </a>
              <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors">
                <Youtube className="w-6 h-6" />
              </a>
              <a href="#" className="text-gray-300 hover:text-blue-400 transition-colors">
                <Linkedin className="w-6 h-6" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; 2025 Fixvia. Alla rättigheter förbehållna.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;